# -*- coding: utf-8 -*-
__author__ = 'twodogegg'

# class FateadmApi:
#     def __init__(self):
